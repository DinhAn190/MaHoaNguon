package week_03;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

/**
 * Hàm dựng giao diện dùng chung cho các form Lab 3 (viết tay bằng GridBagLayout).
 * Bố cục 2 cột: cột 0 là nhãn (Plaintext:, Public key: ...), cột 1 là ô nhập / hàng nút.
 */
final class FormUI {

    private FormUI() {
    }

    /** Panel gốc của form, có lề 12 px. */
    static JPanel root() {
        JPanel p = new JPanel(new GridBagLayout());
        p.setBorder(BorderFactory.createEmptyBorder(10, 12, 10, 12));
        return p;
    }

    /** Nhãn tiêu đề in đậm, chiếm cả 2 cột. */
    static void title(JPanel root, int y, String text, int fontSize) {
        JLabel l = new JLabel(text);
        l.setFont(new Font("Segoe UI", Font.BOLD, fontSize));
        GridBagConstraints g = base(0, y);
        g.gridwidth = 2;
        g.insets = new Insets(2, 0, 10, 0);
        root.add(l, g);
    }

    /** Một hàng: nhãn bên trái (rộng 100 px) + thành phần bên phải. weighty > 0 thì giãn theo chiều dọc. */
    static void row(JPanel root, int y, String labelText, Component comp, double weighty) {
        if (labelText != null) {
            JLabel l = new JLabel(labelText);
            l.setPreferredSize(new Dimension(100, 22));
            GridBagConstraints gl = base(0, y);
            gl.anchor = weighty > 0 ? GridBagConstraints.NORTHWEST : GridBagConstraints.WEST;
            root.add(l, gl);
        }
        GridBagConstraints g = base(1, y);
        g.weightx = 1;
        g.weighty = weighty;
        g.fill = weighty > 0 ? GridBagConstraints.BOTH : GridBagConstraints.HORIZONTAL;
        root.add(comp, g);
    }

    /** Một thành phần chiếm cả 2 cột (bảng, nhãn trạng thái...). */
    static void full(JPanel root, int y, Component comp, double weighty) {
        GridBagConstraints g = base(0, y);
        g.gridwidth = 2;
        g.weightx = 1;
        g.weighty = weighty;
        g.fill = weighty > 0 ? GridBagConstraints.BOTH : GridBagConstraints.HORIZONTAL;
        root.add(comp, g);
    }

    /** Bọc Text Area vào JScrollPane (giống NetBeans tự bọc), đặt lineWrap/rows/editable và cỡ gợi ý. */
    static JScrollPane area(JTextArea a, int rows, boolean editable, int w, int h) {
        a.setLineWrap(true);
        a.setRows(rows);
        a.setEditable(editable);
        a.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        JScrollPane sp = new JScrollPane(a);
        sp.setPreferredSize(new Dimension(w, h));
        sp.setMinimumSize(new Dimension(200, Math.min(h, 46)));
        return sp;
    }

    /** Hàng các thành phần nằm ngang, căn trái. */
    static JPanel flow(Component... cs) {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
        for (int i = 0; i < cs.length; i++) {
            if (i > 0) {
                p.add(Box.createHorizontalStrut(8));
            }
            if (cs[i] instanceof JComponent jc) {
                jc.setMaximumSize(jc.getPreferredSize());
                jc.setAlignmentY(Component.CENTER_ALIGNMENT);
            }
            p.add(cs[i]);
        }
        p.add(Box.createHorizontalGlue());
        return p;
    }

    /** Đặt cỡ gợi ý (rộng × cao) cho một điều khiển. */
    static <T extends JComponent> T size(T c, int w, int h) {
        c.setPreferredSize(new Dimension(w, h));
        return c;
    }

    private static GridBagConstraints base(int x, int y) {
        GridBagConstraints g = new GridBagConstraints();
        g.gridx = x;
        g.gridy = y;
        g.anchor = GridBagConstraints.WEST;
        g.insets = new Insets(4, 0, 4, 8);
        return g;
    }
}