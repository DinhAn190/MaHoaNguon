package week_03;

import javax.swing.JPanel;
import javax.swing.JScrollPane;

/** Form xem lịch sử thao tác trong bảng dbo.History (Bảng 3.5). */
public class frm_LichSu extends javax.swing.JFrame {

    public frm_LichSu() {
        initComponents();
        setLocationRelativeTo(null);
        tbl_history.setModel(HistoryDao.emptyModel());
        loadData();
    }

    /** Đọc 50 dòng mới nhất từ SQL Server và hiện lên JTable. */
    private void loadData() {
        try {
            tbl_history.setModel(HistoryDao.loadLatest(50));
            lbl_status.setText("Đã tải " + tbl_history.getRowCount() + " dòng mới nhất từ dbo.History.");
        } catch (java.sql.SQLException ex) {
            lbl_status.setText("Không đọc được lịch sử: " + ex.getMessage());
        }
    }

    private void initComponents() {
        tbl_history = new javax.swing.JTable();
        btn_refresh = new javax.swing.JButton("Tải lại");
        lbl_status = new javax.swing.JLabel("Đang tải...");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Lịch sử thao tác (SQL Server)");

        tbl_history.setFillsViewportHeight(true);
        tbl_history.setRowHeight(22);
        JScrollPane sp = FormUI.size(new JScrollPane(tbl_history), 760, 260);

        JPanel root = FormUI.root();
        FormUI.title(root, 0, "LỊCH SỬ THAO TÁC - BẢNG DBO.HISTORY", 18);
        FormUI.full(root, 1, sp, 1);
        FormUI.full(root, 2, FormUI.flow(FormUI.size(btn_refresh, 110, 30), FormUI.size(lbl_status, 640, 22)), 0);

        btn_refresh.addActionListener(this::btn_refreshActionPerformed);

        setContentPane(root);
        pack();
    }

    private void btn_refreshActionPerformed(java.awt.event.ActionEvent evt) {
        loadData();
    }

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> new frm_LichSu().setVisible(true));
    }

    private javax.swing.JButton btn_refresh;
    private javax.swing.JLabel lbl_status;
    private javax.swing.JTable tbl_history;
}