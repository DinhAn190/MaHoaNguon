package week_03;

import javax.swing.JOptionPane;
import javax.swing.JPanel;

/** Bài 3.3 - ECC (ECIES: ECDH + HKDF + AES-GCM) trên secp256r1 (Bảng 3.10). */
public class frm_ECC extends javax.swing.JFrame {

    private final ECCCipher ecc = new ECCCipher();

    public frm_ECC() {
        initComponents();
        setLocationRelativeTo(null);
    }

    /** Hiện khóa công khai / khóa riêng (Base64) lên form. */
    private void showKeys() {
        txt_public.setText(ecc.getPublicKeyBase64());
        txt_private.setText(ecc.getPrivateKeyBase64());
        txt_public.setCaretPosition(0);
        txt_private.setCaretPosition(0);
    }

    private void initComponents() {
        txt_public = new javax.swing.JTextArea();
        txt_private = new javax.swing.JTextArea();
        btn_generate = new javax.swing.JButton("Generate Keys");
        btn_savekeys = new javax.swing.JButton("Save Keys");
        btn_loadkeys = new javax.swing.JButton("Load Keys");
        txt_plaintext = new javax.swing.JTextArea();
        txt_ciphertext = new javax.swing.JTextArea();
        btn_encrypt = new javax.swing.JButton("Encrypt");
        btn_decrypt = new javax.swing.JButton("Decrypt");
        lbl_status = new javax.swing.JLabel("Bấm Generate Keys hoặc Load Keys.");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("ECC Cipher");

        JPanel root = FormUI.root();
        FormUI.title(root, 0, "MẬT MÃ ĐƯỜNG CONG ELLIPTIC (ECC - secp256r1)", 18);
        FormUI.row(root, 1, "Public key:", FormUI.area(txt_public, 2, false, 600, 46), 0);
        FormUI.row(root, 2, "Private key:", FormUI.area(txt_private, 2, false, 600, 46), 0);
        FormUI.row(root, 3, null, FormUI.flow(FormUI.size(btn_generate, 140, 30),
                FormUI.size(btn_savekeys, 120, 30), FormUI.size(btn_loadkeys, 120, 30)), 0);
        FormUI.row(root, 4, "Plaintext:", FormUI.area(txt_plaintext, 2, true, 600, 56), 0.4);
        FormUI.row(root, 5, "Ciphertext:", FormUI.area(txt_ciphertext, 3, true, 600, 80), 0.6);
        FormUI.row(root, 6, null, FormUI.flow(FormUI.size(btn_encrypt, 110, 30), FormUI.size(btn_decrypt, 110, 30)), 0);
        FormUI.full(root, 7, FormUI.size(lbl_status, 600, 36), 0);

        btn_generate.addActionListener(this::btn_generateActionPerformed);
        btn_savekeys.addActionListener(this::btn_savekeysActionPerformed);
        btn_loadkeys.addActionListener(this::btn_loadkeysActionPerformed);
        btn_encrypt.addActionListener(this::btn_encryptActionPerformed);
        btn_decrypt.addActionListener(this::btn_decryptActionPerformed);

        setContentPane(root);
        pack();
    }

    private void btn_generateActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            ecc.generateKeys();
            showKeys();
            lbl_status.setText("Đã tạo cặp khóa mới. Bản mã/chữ ký cũ sẽ không dùng được với khóa mới.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Không tạo được khóa: " + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void btn_savekeysActionPerformed(java.awt.event.ActionEvent evt) {
        if (txt_public.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Chưa có khóa để lưu.");
            return;
        }
        String content = CryptoSupport.toKeyFile(txt_public.getText(), txt_private.getText());
        String path = FileTextIO.saveString(this, content, "ecc_keys.txt");
        if (path != null) {
            lbl_status.setText("Đã lưu khóa vào: " + path + " (giữ bí mật dòng PRIVATE).");
        }
    }

    private void btn_loadkeysActionPerformed(java.awt.event.ActionEvent evt) {
        String content = FileTextIO.openString(this);
        if (content == null) {
            return;
        }
        try {
            String[] keys = CryptoSupport.fromKeyFile(content);
            ecc.loadKeys(keys[0], keys[1]);
            txt_public.setText(keys[0]);
            txt_private.setText(keys[1]);
            lbl_status.setText("Đã nạp khóa từ tệp.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Tệp khóa không hợp lệ: " + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void btn_encryptActionPerformed(java.awt.event.ActionEvent evt) {
        String plaintext = txt_plaintext.getText();
        if (plaintext.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Hãy nhập Plaintext trước khi mã hóa.");
            return;
        }
        try {
            String ciphertext = ecc.encrypt(plaintext);
            txt_ciphertext.setText(ciphertext);
            txt_ciphertext.setCaretPosition(0);
            lbl_status.setText("Đã mã hóa ECC (" + ciphertext.length() + " ký tự Base64). "
                    + HistoryDao.tryInsert("ECC", "ENCRYPT", plaintext.length(), true));
        } catch (Exception ex) {
            HistoryDao.tryInsert("ECC", "ENCRYPT", plaintext.length(), false);
            JOptionPane.showMessageDialog(this, "Mã hóa thất bại: " + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void btn_decryptActionPerformed(java.awt.event.ActionEvent evt) {
        String ciphertext = txt_ciphertext.getText();
        if (ciphertext.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Hãy nhập Ciphertext trước khi giải mã.");
            return;
        }
        try {
            String plaintext = ecc.decrypt(ciphertext);
            txt_plaintext.setText(plaintext);
            txt_plaintext.setCaretPosition(0);
            lbl_status.setText("Đã giải mã ECC. " + HistoryDao.tryInsert("ECC", "DECRYPT", ciphertext.length(), true));
        } catch (Exception ex) {
            HistoryDao.tryInsert("ECC", "DECRYPT", ciphertext.length(), false);
            lbl_status.setText("Giải mã ECC THẤT BẠI (sai khóa hoặc bản mã bị sửa).");
            JOptionPane.showMessageDialog(this, "Giải mã thất bại: sai khóa riêng hoặc bản mã bị sửa.\n" + ex,
                    "Giải mã thất bại", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> new frm_ECC().setVisible(true));
    }

    private javax.swing.JButton btn_decrypt;
    private javax.swing.JButton btn_encrypt;
    private javax.swing.JButton btn_generate;
    private javax.swing.JButton btn_loadkeys;
    private javax.swing.JButton btn_savekeys;
    private javax.swing.JLabel lbl_status;
    private javax.swing.JTextArea txt_ciphertext;
    private javax.swing.JTextArea txt_plaintext;
    private javax.swing.JTextArea txt_private;
    private javax.swing.JTextArea txt_public;
}