package week_03;

import javax.swing.JPanel;

/** Cửa sổ chính Lab 3 (Bảng 3.14). Run Project (F6) mở form này. */
public class frm_Menu extends javax.swing.JFrame {

    public frm_Menu() {
        initComponents();
        setLocationRelativeTo(null);
    }

    private void initComponents() {
        btn_rsa = new javax.swing.JButton("3.2 RSA (Swing)");
        btn_ecc = new javax.swing.JButton("3.3 ECC");
        btn_rsaaes = new javax.swing.JButton("3.4 RSA + AES");
        btn_signature = new javax.swing.JButton("3.5 Chữ ký ECDSA");
        btn_sql = new javax.swing.JButton("Kết nối SQL Server");
        btn_history = new javax.swing.JButton("Xem lịch sử");

        // Riêng frm_Menu đóng thì thoát cả chương trình.
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("LAB 3 - Mã hóa khóa công khai");

        JPanel root = FormUI.root();
        FormUI.title(root, 0, "LAB 3 - MÃ HÓA KHÓA CÔNG KHAI", 20);
        FormUI.full(root, 1, FormUI.size(new javax.swing.JLabel(
                "Chọn một bài để mở form tương ứng (bài 3.1 chạy RSADemo.java bằng Run File):"), 640, 22), 0);
        FormUI.full(root, 2, FormUI.flow(FormUI.size(btn_rsa, 200, 30), FormUI.size(btn_ecc, 200, 30),
                FormUI.size(btn_rsaaes, 200, 30)), 0);
        FormUI.full(root, 3, FormUI.flow(FormUI.size(btn_signature, 200, 30), FormUI.size(btn_sql, 200, 30),
                FormUI.size(btn_history, 200, 30)), 0);

        btn_rsa.addActionListener(this::btn_rsaActionPerformed);
        btn_ecc.addActionListener(this::btn_eccActionPerformed);
        btn_rsaaes.addActionListener(this::btn_rsaaesActionPerformed);
        btn_signature.addActionListener(this::btn_signatureActionPerformed);
        btn_sql.addActionListener(this::btn_sqlActionPerformed);
        btn_history.addActionListener(this::btn_historyActionPerformed);

        setContentPane(root);
        pack();
    }

    private void btn_rsaActionPerformed(java.awt.event.ActionEvent evt) {
        new frm_RSA().setVisible(true);
    }

    private void btn_eccActionPerformed(java.awt.event.ActionEvent evt) {
        new frm_ECC().setVisible(true);
    }

    private void btn_rsaaesActionPerformed(java.awt.event.ActionEvent evt) {
        new frm_RSA_AES().setVisible(true);
    }

    private void btn_signatureActionPerformed(java.awt.event.ActionEvent evt) {
        new frm_ECC_Signature().setVisible(true);
    }

    private void btn_sqlActionPerformed(java.awt.event.ActionEvent evt) {
        new frm_KetNoiSQL().setVisible(true);
    }

    private void btn_historyActionPerformed(java.awt.event.ActionEvent evt) {
        new frm_LichSu().setVisible(true);
    }

    public static void main(String[] args) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ex) {
            // giữ giao diện mặc định
        }
        java.awt.EventQueue.invokeLater(() -> new frm_Menu().setVisible(true));
    }

    private javax.swing.JButton btn_ecc;
    private javax.swing.JButton btn_history;
    private javax.swing.JButton btn_rsa;
    private javax.swing.JButton btn_rsaaes;
    private javax.swing.JButton btn_signature;
    private javax.swing.JButton btn_sql;
}