package week_03;

import javax.swing.JOptionPane;
import javax.swing.JPanel;

/** Form kết nối Microsoft SQL Server (Bảng 3.4). Mật khẩu chỉ nhập lúc chạy, không lưu ra tệp. */
public class frm_KetNoiSQL extends javax.swing.JFrame {

    public frm_KetNoiSQL() {
        initComponents();
        setLocationRelativeTo(null);
    }

    private void initComponents() {
        txt_server = new javax.swing.JTextField("127.0.0.1");
        txt_port = new javax.swing.JTextField("14333");
        txt_database = new javax.swing.JTextField("LAB3_MaHoaKhoaCongKhai");
        txt_user = new javax.swing.JTextField("lab3_user");
        txt_password = new javax.swing.JPasswordField();
        btn_test = new javax.swing.JButton("Test Connection");
        btn_history = new javax.swing.JButton("Xem lịch sử");
        lbl_status = new javax.swing.JLabel("Chưa kết nối.");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Kết nối Microsoft SQL Server");

        JPanel root = FormUI.root();
        FormUI.title(root, 0, "KẾT NỐI MICROSOFT SQL SERVER", 18);
        FormUI.row(root, 1, "Server:", FormUI.flow(FormUI.size(txt_server, 320, 28)), 0);
        FormUI.row(root, 2, "Port:", FormUI.flow(FormUI.size(txt_port, 120, 28)), 0);
        FormUI.row(root, 3, "Database:", FormUI.flow(FormUI.size(txt_database, 320, 28)), 0);
        FormUI.row(root, 4, "User:", FormUI.flow(FormUI.size(txt_user, 320, 28)), 0);
        FormUI.row(root, 5, "Password:", FormUI.flow(FormUI.size(txt_password, 320, 28)), 0);
        FormUI.row(root, 6, null, FormUI.flow(FormUI.size(btn_test, 150, 30), FormUI.size(btn_history, 130, 30)), 0);
        FormUI.full(root, 7, FormUI.size(lbl_status, 450, 40), 0);

        btn_test.addActionListener(this::btn_testActionPerformed);
        btn_history.addActionListener(this::btn_historyActionPerformed);
        getRootPane().setDefaultButton(btn_test);

        setContentPane(root);
        pack();
    }

    private void btn_testActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            int port = Integer.parseInt(txt_port.getText().trim());
            DbConfig.set(txt_server.getText().trim(), port, txt_database.getText().trim(),
                    txt_user.getText().trim(), txt_password.getPassword());
            lbl_status.setText("<html>" + DbConfig.test() + "</html>");
        } catch (Exception ex) {
            DbConfig.clear();
            lbl_status.setText("<html>Kết nối thất bại: " + ex.getMessage() + "</html>");
            JOptionPane.showMessageDialog(this, ex.getMessage(),
                    "Không kết nối được SQL Server", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void btn_historyActionPerformed(java.awt.event.ActionEvent evt) {
        new frm_LichSu().setVisible(true);
    }

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> new frm_KetNoiSQL().setVisible(true));
    }

    private javax.swing.JButton btn_history;
    private javax.swing.JButton btn_test;
    private javax.swing.JLabel lbl_status;
    private javax.swing.JTextField txt_database;
    private javax.swing.JPasswordField txt_password;
    private javax.swing.JTextField txt_port;
    private javax.swing.JTextField txt_server;
    private javax.swing.JTextField txt_user;
}