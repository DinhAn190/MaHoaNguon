package week_03;

import javax.swing.JOptionPane;
import javax.swing.JPanel;

/** Bài 3.5 - Chữ ký số ECDSA (SHA256withECDSA, secp256r1) (Bảng 3.13). */
public class frm_ECC_Signature extends javax.swing.JFrame {

    private final ECCSignature ecdsa = new ECCSignature();

    public frm_ECC_Signature() {
        initComponents();
        setLocationRelativeTo(null);
    }

    /** Hiện khóa công khai / khóa riêng (Base64) lên form. */
    private void showKeys() {
        txt_public.setText(ecdsa.getPublicKeyBase64());
        txt_private.setText(ecdsa.getPrivateKeyBase64());
        txt_public.setCaretPosition(0);
        txt_private.setCaretPosition(0);
    }

    private void initComponents() {
        txt_public = new javax.swing.JTextArea();
        txt_private = new javax.swing.JTextArea();
        btn_generate = new javax.swing.JButton("Generate Keys");
        btn_savekeys = new javax.swing.JButton("Save Keys");
        btn_loadkeys = new javax.swing.JButton("Load Keys");
        txt_message = new javax.swing.JTextArea();
        txt_signature = new javax.swing.JTextArea();
        btn_sign = new javax.swing.JButton("Sign");
        btn_verify = new javax.swing.JButton("Verify");
        lbl_result = new javax.swing.JLabel("");
        lbl_status = new javax.swing.JLabel("Bấm Generate Keys hoặc Load Keys.");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("ECDSA Signature");
        lbl_result.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 20));

        JPanel root = FormUI.root();
        FormUI.title(root, 0, "CHỮ KÝ SỐ ECDSA (SHA256withECDSA)", 18);
        FormUI.row(root, 1, "Public key:", FormUI.area(txt_public, 2, false, 600, 46), 0);
        FormUI.row(root, 2, "Private key:", FormUI.area(txt_private, 2, false, 600, 46), 0);
        FormUI.row(root, 3, null, FormUI.flow(FormUI.size(btn_generate, 140, 30),
                FormUI.size(btn_savekeys, 120, 30), FormUI.size(btn_loadkeys, 120, 30)), 0);
        FormUI.row(root, 4, "Message:", FormUI.area(txt_message, 2, true, 600, 56), 0.5);
        FormUI.row(root, 5, "Signature:", FormUI.area(txt_signature, 2, true, 600, 56), 0.5);
        FormUI.row(root, 6, null, FormUI.flow(FormUI.size(btn_sign, 110, 30),
                FormUI.size(btn_verify, 110, 30), FormUI.size(lbl_result, 300, 38)), 0);
        FormUI.full(root, 7, FormUI.size(lbl_status, 600, 36), 0);

        btn_generate.addActionListener(this::btn_generateActionPerformed);
        btn_savekeys.addActionListener(this::btn_savekeysActionPerformed);
        btn_loadkeys.addActionListener(this::btn_loadkeysActionPerformed);
        btn_sign.addActionListener(this::btn_signActionPerformed);
        btn_verify.addActionListener(this::btn_verifyActionPerformed);

        setContentPane(root);
        pack();
    }

    private void btn_generateActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            ecdsa.generateKeys();
            showKeys();
            lbl_result.setText("");
            lbl_status.setText("Đã tạo cặp khóa mới. Bản mã/chữ ký cũ sẽ không dùng được với khóa mới.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Không tạo được khóa: " + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void btn_savekeysActionPerformed(java.awt.event.ActionEvent evt) {
        if (txt_public.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Chưa có khóa để lưu.");
            return;
        }
        String content = CryptoSupport.toKeyFile(txt_public.getText(), txt_private.getText());
        String path = FileTextIO.saveString(this, content, "ecdsa_keys.txt");
        if (path != null) {
            lbl_status.setText("Đã lưu khóa vào: " + path + " (giữ bí mật dòng PRIVATE).");
        }
    }

    private void btn_loadkeysActionPerformed(java.awt.event.ActionEvent evt) {
        String content = FileTextIO.openString(this);
        if (content == null) {
            return;
        }
        try {
            String[] keys = CryptoSupport.fromKeyFile(content);
            ecdsa.loadKeys(keys[0], keys[1]);
            txt_public.setText(keys[0]);
            txt_private.setText(keys[1]);
            lbl_result.setText("");
            lbl_status.setText(keys[1].isEmpty()
                    ? "Đã nạp KHÓA CÔNG KHAI (không có khóa riêng): chỉ Verify được, không Sign được."
                    : "Đã nạp khóa từ tệp.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Tệp khóa không hợp lệ: " + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void btn_signActionPerformed(java.awt.event.ActionEvent evt) {
        String message = txt_message.getText();
        try {
            txt_signature.setText(ecdsa.sign(message));
            lbl_result.setText("");
            lbl_status.setText("Đã ký bằng KHÓA RIÊNG. " + HistoryDao.tryInsert("ECDSA", "SIGN", message.length(), true));
        } catch (Exception ex) {
            HistoryDao.tryInsert("ECDSA", "SIGN", message.length(), false);
            JOptionPane.showMessageDialog(this, "Ký thất bại: " + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void btn_verifyActionPerformed(java.awt.event.ActionEvent evt) {
        String message = txt_message.getText();
        try {
            boolean ok = ecdsa.verify(message, txt_signature.getText());
            lbl_result.setText(ok ? "VALID" : "INVALID");
            lbl_result.setForeground(ok ? new java.awt.Color(0, 128, 0) : java.awt.Color.RED);
            lbl_status.setText("Đã xác minh bằng KHÓA CÔNG KHAI. " + HistoryDao.tryInsert("ECDSA", "VERIFY", message.length(), ok));
        } catch (Exception ex) {
            HistoryDao.tryInsert("ECDSA", "VERIFY", message.length(), false);
            JOptionPane.showMessageDialog(this, "Xác minh thất bại: " + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> new frm_ECC_Signature().setVisible(true));
    }

    private javax.swing.JButton btn_generate;
    private javax.swing.JButton btn_loadkeys;
    private javax.swing.JButton btn_savekeys;
    private javax.swing.JButton btn_sign;
    private javax.swing.JButton btn_verify;
    private javax.swing.JLabel lbl_result;
    private javax.swing.JLabel lbl_status;
    private javax.swing.JTextArea txt_message;
    private javax.swing.JTextArea txt_private;
    private javax.swing.JTextArea txt_public;
    private javax.swing.JTextArea txt_signature;
}