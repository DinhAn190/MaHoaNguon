package week_03;

import javax.swing.JOptionPane;
import javax.swing.JPanel;

/** Bài 3.2 - RSA-OAEP với giao diện Swing (Bảng 3.8). */
public class frm_RSA extends javax.swing.JFrame {

    /** Đối tượng RSA giữ cặp khóa trong suốt thời gian form mở. */
    private final RSACipher rsa = new RSACipher();

    public frm_RSA() {
        initComponents();
        setLocationRelativeTo(null);
    }

    private void initComponents() {
        cbo_bits = new javax.swing.JComboBox<>(new String[] {"2048", "3072"});
        btn_generate = new javax.swing.JButton("Generate Keys");
        lbl_keyinfo = new javax.swing.JLabel("Chưa có khóa.");
        txt_plaintext = new javax.swing.JTextArea();
        txt_ciphertext = new javax.swing.JTextArea();
        btn_encrypt = new javax.swing.JButton("Encrypt");
        btn_decrypt = new javax.swing.JButton("Decrypt");
        lbl_status = new javax.swing.JLabel("Bấm Generate Keys để tạo cặp khóa.");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("RSA Cipher");

        JPanel root = FormUI.root();
        FormUI.title(root, 0, "MẬT MÃ RSA (OAEP - SHA-256)", 18);
        FormUI.row(root, 1, "Key size:", FormUI.flow(FormUI.size(cbo_bits, 110, 28),
                FormUI.size(btn_generate, 140, 30), FormUI.size(lbl_keyinfo, 330, 22)), 0);
        FormUI.row(root, 2, "Plaintext:", FormUI.area(txt_plaintext, 2, true, 600, 60), 0.35);
        FormUI.row(root, 3, "Ciphertext:", FormUI.area(txt_ciphertext, 3, true, 600, 110), 0.65);
        FormUI.row(root, 4, null, FormUI.flow(FormUI.size(btn_encrypt, 110, 30), FormUI.size(btn_decrypt, 110, 30)), 0);
        FormUI.full(root, 5, FormUI.size(lbl_status, 600, 36), 0);

        btn_generate.addActionListener(this::btn_generateActionPerformed);
        btn_encrypt.addActionListener(this::btn_encryptActionPerformed);
        btn_decrypt.addActionListener(this::btn_decryptActionPerformed);

        setContentPane(root);
        pack();
    }

    private void btn_generateActionPerformed(java.awt.event.ActionEvent evt) {
        int bits = Integer.parseInt((String) cbo_bits.getSelectedItem());
        try {
            long start = System.currentTimeMillis();
            rsa.generateKeys(bits);
            long ms = System.currentTimeMillis() - start;
            lbl_keyinfo.setText("RSA-" + bits + ": tạo khóa " + ms + " ms, tối đa " + rsa.maxPlaintextBytes() + " byte");
            lbl_status.setText("Đã tạo cặp khóa. Khóa công khai dùng để mã hóa, khóa riêng để giải mã.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Không tạo được khóa: " + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void btn_encryptActionPerformed(java.awt.event.ActionEvent evt) {
        String plaintext = txt_plaintext.getText();
        if (plaintext.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Hãy nhập Plaintext trước khi mã hóa.");
            return;
        }
        try {
            String ciphertext = rsa.encrypt(plaintext);
            txt_ciphertext.setText(ciphertext);
            txt_ciphertext.setCaretPosition(0);
            lbl_status.setText("Đã mã hóa RSA (" + ciphertext.length() + " ký tự Base64). "
                    + HistoryDao.tryInsert("RSA", "ENCRYPT", plaintext.length(), true));
        } catch (Exception ex) {
            HistoryDao.tryInsert("RSA", "ENCRYPT", plaintext.length(), false);
            JOptionPane.showMessageDialog(this, "Mã hóa thất bại: " + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void btn_decryptActionPerformed(java.awt.event.ActionEvent evt) {
        String ciphertext = txt_ciphertext.getText();
        if (ciphertext.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Hãy nhập Ciphertext trước khi giải mã.");
            return;
        }
        try {
            String plaintext = rsa.decrypt(ciphertext);
            txt_plaintext.setText(plaintext);
            txt_plaintext.setCaretPosition(0);
            lbl_status.setText("Đã giải mã RSA. " + HistoryDao.tryInsert("RSA", "DECRYPT", ciphertext.length(), true));
        } catch (Exception ex) {
            HistoryDao.tryInsert("RSA", "DECRYPT", ciphertext.length(), false);
            lbl_status.setText("Giải mã RSA THẤT BẠI (sai khóa hoặc bản mã bị sửa).");
            JOptionPane.showMessageDialog(this, "Giải mã thất bại: sai khóa riêng hoặc bản mã bị sửa.\n" + ex,
                    "Giải mã thất bại", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> new frm_RSA().setVisible(true));
    }

    private javax.swing.JButton btn_decrypt;
    private javax.swing.JButton btn_encrypt;
    private javax.swing.JButton btn_generate;
    private javax.swing.JComboBox<String> cbo_bits;
    private javax.swing.JLabel lbl_keyinfo;
    private javax.swing.JLabel lbl_status;
    private javax.swing.JTextArea txt_ciphertext;
    private javax.swing.JTextArea txt_plaintext;
}