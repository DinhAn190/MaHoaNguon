package week_01;

import javax.swing.JOptionPane;

public class frm_TongHop extends javax.swing.JFrame {

    private javax.swing.JComboBox<String> cbo_algorithm;
    private javax.swing.JLabel lbl_hint;
    private javax.swing.JTextArea txt_plaintext;
    private javax.swing.JTextField txt_key;
    private javax.swing.JTextArea txt_ciphertext;
    private javax.swing.JButton btn_encrypt;
    private javax.swing.JButton btn_decrypt;
    private javax.swing.JButton btn_open;
    private javax.swing.JButton btn_save;
    private javax.swing.JButton btn_sql;
    private javax.swing.JButton btn_history;
    private javax.swing.JLabel lbl_status;

    public frm_TongHop() {
        setTitle("Chương trình tổng hợp - 6 thuật toán");
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        javax.swing.JLabel lblTitle = new javax.swing.JLabel("CHƯƠNG TRÌNH TỔNG HỢP 6 THUẬT TOÁN CỔ ĐIỂN");
        lblTitle.setFont(new java.awt.Font("Segoe UI", 1, 18));

        cbo_algorithm = new javax.swing.JComboBox<>(CipherTongHop.ALGORITHMS);
        lbl_hint = new javax.swing.JLabel("Khóa mẫu: 3");
        txt_plaintext = new javax.swing.JTextArea(3, 40);
        txt_plaintext.setLineWrap(true);
        txt_key = new javax.swing.JTextField("3", 20);
        txt_ciphertext = new javax.swing.JTextArea(3, 40);
        txt_ciphertext.setLineWrap(true);

        btn_encrypt = new javax.swing.JButton("Encrypt");
        btn_decrypt = new javax.swing.JButton("Decrypt");
        btn_open = new javax.swing.JButton("Open File");
        btn_save = new javax.swing.JButton("Save File");
        btn_sql = new javax.swing.JButton("Kết nối SQL Server");
        btn_history = new javax.swing.JButton("Xem lịch sử");
        lbl_status = new javax.swing.JLabel("Sẵn sàng.");

        cbo_algorithm.addActionListener(e -> {
            String algorithm = (String) cbo_algorithm.getSelectedItem();
            txt_key.setText(CipherTongHop.sampleKey(algorithm));
            lbl_hint.setText("Khóa mẫu: " + CipherTongHop.sampleKey(algorithm));
        });
        btn_encrypt.addActionListener(e -> encrypt());
        btn_decrypt.addActionListener(e -> decrypt());
        btn_open.addActionListener(e -> {
            String path = FileTextIO.openText(this, txt_ciphertext);
            if (path != null) lbl_status.setText("Đã mở tệp: " + path);
        });
        btn_save.addActionListener(e -> {
            String path = FileTextIO.saveText(this, txt_ciphertext, "ciphertext.txt");
            if (path != null) lbl_status.setText("Đã lưu tệp: " + path);
        });
        btn_sql.addActionListener(e -> new frm_KetNoiSQL().setVisible(true));
        btn_history.addActionListener(e -> new frm_LichSu().setVisible(true));

        javax.swing.JPanel algoRow = new javax.swing.JPanel(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 10, 0));
        algoRow.add(cbo_algorithm);
        algoRow.add(lbl_hint);

        javax.swing.JPanel buttons1 = new javax.swing.JPanel(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 10, 0));
        buttons1.add(btn_encrypt);
        buttons1.add(btn_decrypt);
        buttons1.add(btn_open);
        buttons1.add(btn_save);

        javax.swing.JPanel buttons2 = new javax.swing.JPanel(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 10, 0));
        buttons2.add(btn_sql);
        buttons2.add(btn_history);

        javax.swing.JPanel form = new javax.swing.JPanel(new java.awt.GridBagLayout());
        form.setBorder(javax.swing.BorderFactory.createEmptyBorder(15, 20, 15, 20));
        java.awt.GridBagConstraints c = new java.awt.GridBagConstraints();
        c.insets = new java.awt.Insets(6, 6, 6, 6);
        c.anchor = java.awt.GridBagConstraints.WEST;

        c.gridx = 0; c.gridy = 0; c.gridwidth = 2;
        form.add(lblTitle, c);
        c.gridwidth = 1;

        c.gridy = 1; c.gridx = 0;
        form.add(new javax.swing.JLabel("Thuật toán:"), c);
        c.gridx = 1;
        form.add(algoRow, c);

        c.gridy = 2; c.gridx = 0; c.anchor = java.awt.GridBagConstraints.NORTHWEST;
        form.add(new javax.swing.JLabel("Plaintext:"), c);
        c.gridx = 1; c.fill = java.awt.GridBagConstraints.HORIZONTAL; c.weightx = 1;
        form.add(new javax.swing.JScrollPane(txt_plaintext), c);

        c.gridy = 3; c.gridx = 0; c.fill = java.awt.GridBagConstraints.NONE; c.weightx = 0;
        c.anchor = java.awt.GridBagConstraints.WEST;
        form.add(new javax.swing.JLabel("Key:"), c);
        c.gridx = 1;
        form.add(txt_key, c);

        c.gridy = 4; c.gridx = 0; c.anchor = java.awt.GridBagConstraints.NORTHWEST;
        form.add(new javax.swing.JLabel("Ciphertext:"), c);
        c.gridx = 1; c.fill = java.awt.GridBagConstraints.HORIZONTAL; c.weightx = 1;
        form.add(new javax.swing.JScrollPane(txt_ciphertext), c);

        c.gridy = 5; c.gridx = 1; c.fill = java.awt.GridBagConstraints.NONE; c.weightx = 0;
        c.anchor = java.awt.GridBagConstraints.WEST;
        form.add(buttons1, c);
        c.gridy = 6;
        form.add(buttons2, c);
        c.gridy = 7;
        form.add(lbl_status, c);

        setContentPane(form);
        pack();
        setLocationRelativeTo(null);
    }

    private void encrypt() {
        String algorithm = (String) cbo_algorithm.getSelectedItem();
        String input = txt_plaintext.getText();
        try {
            String result = CipherTongHop.encrypt(algorithm, input, txt_key.getText());
            txt_ciphertext.setText(result);
            String saved = HistoryDao.tryInsert(algorithm, "ENCRYPT", input, result);
            lbl_status.setText("Đã mã hóa " + algorithm + ". " + saved);
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(),
                    "Dữ liệu không hợp lệ", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void decrypt() {
        String algorithm = (String) cbo_algorithm.getSelectedItem();
        String input = txt_ciphertext.getText();
        try {
            String result = CipherTongHop.decrypt(algorithm, input, txt_key.getText());
            txt_plaintext.setText(result);
            String saved = HistoryDao.tryInsert(algorithm, "DECRYPT", input, result);
            lbl_status.setText("Đã giải mã " + algorithm + ". " + saved);
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(),
                    "Dữ liệu không hợp lệ", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> new frm_TongHop().setVisible(true));
    }
}