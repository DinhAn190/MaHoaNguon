USE [LAB1_MaHoaCoDien];
GO
SELECT TOP (20) id, created_at, algorithm, operation, input_text, result_text
FROM dbo.history ORDER BY id DESC;
GO
